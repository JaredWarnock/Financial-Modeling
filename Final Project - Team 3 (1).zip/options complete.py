import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm, binom
from typing import Callable


## Payoff functions
def call_payoff(spot, strike):
    return np.maximum(spot - strike, 0.0)

def put_payoff(spot, strike):
    return np.maximum(strike - spot, 0.0)

## Pricing functions
def european_binomial_pricer(spot: float, strike: float, expiry: float, rate: float, div: float, vol: float, nper: int, payoff: Callable) -> float:
    h = expiry / nper
    nodes = nper + 1
    DF = np.exp(-rate * expiry)
    u = np.exp((rate- div)*h + vol*h**(1/2))
    d = np.exp((rate- div)*h - vol*h**(1/2))
    pstar = (np.exp((rate - div)*h) - d) / (u - d)
    
    spot_t = 0
    call_t = 0
    
    for time in range(nodes):
        spot_t = spot * (u ** (nper - time)) * (d ** time)
        call_t += payoff(spot_t, strike) * binom.pmf((nper - time), nper, pstar)
    return call_t * DF

def american_binomial_pricer(spot: float, strike: float, expiry: float, rate: float, div: float, vol: float, num: int, payoff: Callable) -> float:
    nodes = num + 1
    h = expiry / num 
    up = np.exp(((rate - div) * h) + vol * np.sqrt(h)) 
    down = np.exp(((rate - div) * h) - vol * np.sqrt(h))
    prob_up = (np.exp((rate - div) * h) - down) / (up - down)
    prob_down = 1 - prob_up
    discount = np.exp(-rate * h)
    opt_vals = np.zeros(nodes)
    spot_vals = np.zeros(nodes)
    for j in range(nodes):
        spot_vals[j] = spot * (up ** (num - j)) * (down ** j)
        opt_vals[j] = payoff(spot_vals[j], strike)
    for t in range((num - 1), -1, -1):
        for k in range(t+1):
            opt_vals[k] = discount * (prob_up * opt_vals[k] + prob_down * opt_vals[k+1])
            spot_vals[k] /= up
            opt_vals[k] = np.maximum(opt_vals[k], payoff(spot_vals[k], strike))
    return opt_vals[0]

def black_scholes_call(spot: float, strike: float, expiry: float, rate: float, div: float, vol: float) -> float:
    d1 = (np.log(spot/strike) + (rate - div + 0.5 * vol * vol) * expiry) / (vol * np.sqrt(expiry))
    d2 = d1 - vol * np.sqrt(expiry) 
    return (spot * np.exp(-div * expiry) * norm.cdf(d1)) - (strike * np.exp(-rate * expiry) * norm.cdf(d2))

def black_scholes_put(spot: float, strike: float, expiry: float, rate: float, div: float, vol: float) -> float:
    d1 = (np.log(spot/strike) + (rate - div + 0.5 * vol * vol) * expiry) / (vol * np.sqrt(expiry))
    d2 = d1 - vol * np.sqrt(expiry) 
    return (strike * np.exp(-rate * expiry) * norm.cdf(-d2)) - (spot * np.exp(-div * expiry) * norm.cdf(-d1))


## Delta
def black_scholes_call_delta(spot: float, strike: float, tau: float, rate: float, div: float, vol: float) -> float:
    d1 = (np.log(spot/strike) + (rate - div + 0.5 * vol * vol) * tau) / (vol * np.sqrt(tau))
    return np.exp(-div * tau) * norm.cdf(d1)


## Simulations
def binomial_path(spot: float, expiry: float, rate: float, div: float, vol: float, num: int) -> np.ndarray:
    h = expiry / num
    u = np.exp((rate - div) * h + np.sqrt(h) * vol)
    d = np.exp((rate - div) * h - np.sqrt(h) * vol)
    pstar = (np.exp((rate - div) * h) - d) / (u - d) 
    z = np.random.uniform(size=num)
    path = np.empty(num)
    path[0] = spot
    for i in range(1, num):
        if z[i] >= pstar: path[i] = u * path[i-1]
        else: z[i] = path[i] = d * path[i-1]
    return path
   